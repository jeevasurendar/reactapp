import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'lib-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.scss']
})
export class InputComponent implements OnInit {
  private _value: string;
  public get value(): string {
    return this._value;
  }
  public set value(value: string) {
    this._value = value;

    this.emitEvent(this._value);
  }
  @Input() disabled: boolean;
  @Input() type: string;

  @Output() eventToEmit: EventEmitter<any> = new EventEmitter();

  constructor() { }

  ngOnInit(): void {
  }

  emitEvent(event) {
    this.eventToEmit.emit(event);
  }

}
