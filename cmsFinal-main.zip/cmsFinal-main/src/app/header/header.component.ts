import { state } from '@angular/animations';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';
import { MasterService } from '../service/master.service';
import { MenuService } from '../service/menu.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  isLoggedIn = this.authService.isUserLoggedIn;

  constructor(
    public authService: AuthenticationService,
    private router: Router,
    public masterService: MasterService,
    private menuService: MenuService
  ) { }

  ngOnInit(): void {
    this.menuService.getMenu(this.masterService.userInfo ? this.masterService.userInfo.userId : '');
  }

  login() {
    this.router.navigate(['/login']);
  }

  logout() {
    this.router.navigate(['/home']);
    this.authService.logout();
  }

}
