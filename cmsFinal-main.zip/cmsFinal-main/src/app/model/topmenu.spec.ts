import { Topmenu } from './topmenu';

describe('Topmenu', () => {
  it('should create an instance', () => {
    expect(new Topmenu()).toBeTruthy();
  });
});
