export class Topmenu {
    name: string;
    url: string;
    subMenu: Topmenu[];
}
