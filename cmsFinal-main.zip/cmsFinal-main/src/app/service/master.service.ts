import { Injectable } from '@angular/core';
import { Leftmenu } from '../model/leftmenu';
import { Topmenu } from '../model/topmenu';
import { User } from '../model/user';

@Injectable({
  providedIn: 'root'
})
export class MasterService {
  public userInfo: User;
  public topMenu: Topmenu[];
  public leftMenu: Leftmenu[];

  constructor() { }
}
