import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accounthome',
  templateUrl: './accounthome.component.html',
  styleUrls: ['./accounthome.component.scss']
})
export class AccounthomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
